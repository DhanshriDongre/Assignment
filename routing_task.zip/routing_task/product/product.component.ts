import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent{

  public prod:any[]  = [];

  constructor()
  {
    this.prod = [
      {pno: 1025, pname : "Ram", price : 56000},
      {pno: 1026, pname : "DVD", price :  65000},
      {pno: 1027, pname : "Hard disk", price :  45000},
    
    ];
  }

  public  f1(n:number):void
  {
    this.prod.splice(n, 1);
  }


  public  f2( ):void
  {
    var obj:any  = {pno: 1025, pname : "Ram", price : 56000};
    this.prod.push(obj);
  }

}
