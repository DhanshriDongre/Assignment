import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  empObj:any = {};

  prod:any[] = [
    {pno: 1025, pname : "Ram", price : 56000},
    {pno: 1026, pname : "DVD", price :  65000},
    {pno: 1027, pname : "Hard disk", price :  45000},
  ];


  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    let eno = this.activatedRoute.snapshot.params["id"];
    // alert("Selected Empno  : " + eno);

    this.empObj = this.prod.find(item => item.pno == eno);
  }


}